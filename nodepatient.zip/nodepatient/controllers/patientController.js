const db = require('../config/db');

// Add Patient Controller
exports.addPatient = async (req, res, next) => {
    try {
        const { name, age, medicalHistory } = req.body;

        // Validate input data
        if (!name || !age || !medicalHistory) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        // Insert patient into the database
        const [result] = await db.execute(
            'INSERT INTO patients (name, age, medical_history) VALUES (?, ?, ?)',
            [name, age, medicalHistory]
        );

        // Send success response
        res.status(201).json({
            message: 'Patient added successfully',
            patientId: result.insertId,
        });
    } catch (error) {
        next(error); // Pass errors to middleware
    }
};

  
 // Update Patient Controller
exports.updatePatient = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { name, age, medicalHistory } = req.body;

        // Check if patient exists
        const [rows] = await db.execute('SELECT * FROM patients WHERE id = ?', [id]);
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Patient not found' });
        }

        // Validate input data
        if (!name || !age || !medicalHistory) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        // Update patient in the database
        await db.execute(
            'UPDATE patients SET name = ?, age = ?, medical_history = ? WHERE id = ?',
            [name, age, medicalHistory, id]
        );

        // Send success response
        res.status(200).json({ message: 'Patient updated successfully' });
    } catch (error) {
        next(error);
    }
};

  
 // Delete Patient Controller
exports.deletePatient = async (req, res, next) => {
    try {
        const { id } = req.params;

        // Check if patient exists
        const [rows] = await db.execute('SELECT * FROM patients WHERE id = ?', [id]);
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Patient not found' });
        }

        // Delete patient from the database
        await db.execute('DELETE FROM patients WHERE id = ?', [id]);

        // Send success response
        res.status(200).json({ message: 'Patient deleted successfully' });
    } catch (error) {
        next(error);
    }
};

  // Get Patients Controller
exports.getPatients = async (req, res, next) => {
    try {
        const { id } = req.params;

        let query = 'SELECT * FROM patients';
        const params = [];

        // Search by ID if provided
        if (id) {
            query += ' WHERE id = ?';
            params.push(id);
        }

        // Fetch records
        const [rows] = await db.execute(query, params);

        // Send response
        res.status(200).json({ patients: rows });
    } catch (error) {
        next(error);
    }
};

  