const express = require('express');
const db = require('../config/db');
const { addPatient, updatePatient, deletePatient, getPatients } = require('../controllers/patientController');

const router = express.Router();

router.post('/', addPatient);
router.put('/:id', updatePatient);
router.delete('/:id', deletePatient);
router.get('/', getPatients);
router.get('/test-db', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT 1');
        res.status(200).json({ message: 'Database connection successful', data: rows });
    } catch (error) {
        res.status(500).json({ message: 'Database connection failed', error: error.message });
    }
});
router.post('/', addPatient);

module.exports = router;
